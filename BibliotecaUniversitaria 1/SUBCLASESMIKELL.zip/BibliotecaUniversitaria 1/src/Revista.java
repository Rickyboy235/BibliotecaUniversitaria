/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
// Subclase Revista
class Revista extends MaterialBibliografico {
    private String numero;
    public Revista(String titulo, String autor, String numero) {
        super(titulo, autor);
        this.numero = numero;
    }
    @Override
    public void mostrarInfo() {
        System.out.println("Titulo: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Numero: " + numero);
    }
}
