/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
class Tesis extends MaterialBibliografico {
    private String universidad;
    public Tesis(String titulo, String autor, String universidad) {
        super(titulo, autor);
        this.universidad = universidad;
    }
    @Override
    public void mostrarInfo() {
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Universidad: " + universidad);
    }
}