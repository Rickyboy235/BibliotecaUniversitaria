/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
class Video extends Multimedia {
    private int duracion; // duración en minutos
    public Video(String titulo, String autor, String formato, int duracion) {
        super(titulo, autor, formato);
        this.duracion = duracion;
    }
    @Override
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Duración: " + duracion + " minutos");
    }
}
